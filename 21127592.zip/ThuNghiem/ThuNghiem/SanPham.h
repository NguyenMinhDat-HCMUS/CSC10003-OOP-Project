#pragma once
#include "Date.h"


using namespace std;

const string THOITRANG = "THOI TRANG";
const string THOITRANGNAM = "THOI TRANG NAM";
const string THOITRANGNU = "THOI TRANG NU";
const string AONAM = "AO NAM";
const string QUANNAM = "QUAN NAM";
const string AONU = "AO NU";
const string QUANNU = "QUAN NU";
const string KHAC = "KHAC";

const string NAM = "NAM";
const string NU = "NU";
const string DANHSACHCUAHANG = "DanhSachCuaHang.txt";
const string DANHSACHKHACHHANG = "DanhSachKhachHang.txt";


class SanPham
{
    string TenSanPham;
    string LoaiSanPham;
    int GiaBan;
    int SoLuongCoSan;
public:
    string getTenSanPham() { return TenSanPham; }
    string getLoaiSanPham() { return LoaiSanPham; }
    int getGiaBan() { return GiaBan; }
    int getSoLuongCoSan() { return SoLuongCoSan; }

    void setTenSanPham(string ten) { this->TenSanPham = ten; }
    void setLoaiSanPham(string loai) { this->LoaiSanPham = loai; }
    void setGiaBan(int gia) { this->GiaBan = gia; }
    void setSoLuongCoSan(int soluong) { this->SoLuongCoSan = soluong; }

    SanPham() {}
    SanPham(string ten, string loai, int gia, int soluong)
    {
        TenSanPham = ten;
        LoaiSanPham = loai;
        GiaBan = gia;
        SoLuongCoSan = soluong;
    }

    void Nhap()
    {
        cout << "Chon Danh Muc: \n";
        cout << "1. " << THOITRANG << '\n';
        cout << "2. " << KHAC << '\n';
        cout << "Lua Chon (1 / 2):  ";

        char choice;
        cin >> choice;
        cin.ignore();

        if (choice == '1')
        {
            cout << "Chon Danh Muc: \n";
            cout << "1. " << THOITRANGNAM << '\n';
            cout << "2. " << THOITRANGNU << '\n';
            cout << "Lua Chon (1 / 2):  ";

            cin >> choice;
            cin.ignore();

            if (choice == '1')
            {
                cout << "Chon Danh Muc: \n";
                cout << "1. " << AONAM << '\n';
                cout << "2. " << QUANNAM << '\n';
                cout << "Lua Chon (1 / 2):  ";

                cin >> choice;
                cin.ignore();

                if (choice == '1')
                {
                    LoaiSanPham = AONAM;
                }
                else
                {
                    LoaiSanPham = QUANNAM;
                }
            }
            else
            {
                cout << "Chon Danh Muc: \n";
                cout << "1. " << AONU << '\n';
                cout << "2. " << QUANNU << '\n';
                cout << "Lua Chon (1 / 2):  ";

                cin >> choice;
                cin.ignore();

                if (choice == '1')
                {
                    LoaiSanPham = AONU;
                }
                else
                {
                    LoaiSanPham = QUANNU;
                }
            }
        }
        else
        {
            LoaiSanPham = KHAC;
        }

        cout << "Nhap Ten San Pham  =  ";
        getline(cin, TenSanPham);

        do {
            cout << "Nhap Gia Ban  =  ";
            cin >> GiaBan;
            cin.ignore();
        } while (GiaBan < 0);


        do {
            cout << "Nhap So Luong Co San  =  ";
            cin >> SoLuongCoSan;
            cin.ignore();
        } while (SoLuongCoSan < 0);

    }
};
