#pragma once
#include "MaGiamGia.h"

using namespace std;


class CuaHang
{
    string TenCuaHang;
    Date NgayThamGia;
    vector<SanPham> DanhSachSanPham;
public:
    CuaHang() {}
    CuaHang(string ten, vector<SanPham> danhsach)
    {
        TenCuaHang = ten;
        DanhSachSanPham = danhsach;
    }

    string getTenCuaHang() { return TenCuaHang; }
    Date getNgayThamGia() { return NgayThamGia; }
    vector<SanPham> getDanhSachSanPham() { return DanhSachSanPham; }

    void setDanhSachSanPham(vector<SanPham> danhsach) { DanhSachSanPham = danhsach; }

    void CapNhatCSDL()
    {
        fstream fout;
        fout.open(TenCuaHang + ".txt", ios::out);

        fout << TenCuaHang << '\n';
        fout << NgayThamGia.getNgay() << '\n';
        fout << NgayThamGia.getThang() << '\n';
        fout << NgayThamGia.getNam() << '\n';

        int SoLuong = DanhSachSanPham.size();

        fout << SoLuong << '\n';

        for (int i = 0; i < SoLuong; i++)
        {
            fout << DanhSachSanPham[i].getTenSanPham() << '\n';
            fout << DanhSachSanPham[i].getLoaiSanPham() << '\n';
            fout << DanhSachSanPham[i].getGiaBan() << '\n';
            fout << DanhSachSanPham[i].getSoLuongCoSan() << '\n';
        }

        fout.close();
    }

    void TruyXuatCSDL(string path)
    {
        fstream fin;
        fin.open(path);

        getline(fin, TenCuaHang);

        int ngay;
        int thang;
        int nam;

        string rac;

        fin >> ngay;
        getline(fin, rac);

        fin >> thang;
        getline(fin, rac);

        fin >> nam;
        getline(fin, rac);

        NgayThamGia.setNgay(ngay);
        NgayThamGia.setThang(thang);
        NgayThamGia.setNam(nam);

        int SoLuongSanPham;
        fin >> SoLuongSanPham;
        getline(fin, rac);

        DanhSachSanPham.resize(SoLuongSanPham);

        for (int i = 0; i < SoLuongSanPham; i++)
        {
            string TenSanPham;
            string LoaiSanPham;
            int GiaBan;
            int SoLuongCoSan;

            getline(fin, TenSanPham);
            getline(fin, LoaiSanPham);

            fin >> GiaBan;
            getline(fin, rac);

            fin >> SoLuongCoSan;
            getline(fin, rac);

            DanhSachSanPham[i].setTenSanPham(TenSanPham);
            DanhSachSanPham[i].setLoaiSanPham(LoaiSanPham);
            DanhSachSanPham[i].setGiaBan(GiaBan);
            DanhSachSanPham[i].setSoLuongCoSan(SoLuongCoSan);
        }

        fin.close();
    }

    void Nhap()
    {
        cout << "Nhap Ten Cua Hang  =  ";
        getline(cin, TenCuaHang);

        cout << "Nhap Ngay Tham Gia: \n";
        NgayThamGia.Nhap();


        int SoLuong;

        do {
            cout << "Nhap So Luong San Pham  =  ";
            cin >> SoLuong;
            cin.ignore();
        } while (SoLuong < 0);

        DanhSachSanPham.resize(SoLuong);

        for (int i = 0; i < SoLuong; i++)
        {
            DanhSachSanPham[i].Nhap();
        }
    }

    void ThemSanPham()
    {
        cout << "Nhap Thong Tin San Pham: \n";

        SanPham temp;
        temp.Nhap();

        DanhSachSanPham.push_back(temp);
        CapNhatCSDL();
        cout << "Them San Pham Thanh Cong \n";
    }

    int TimKiemIndexSanPhamTheoTen()
    {
        cout << "\nDanh Sach San Pham: \n";

        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            cout << i + 1 << ". " << DanhSachSanPham[i].getTenSanPham() << '\n';
        }

        string TenSanPham;
        cout << "Nhap Ten San Pham:  ";
        getline(cin, TenSanPham);

        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            if (DanhSachSanPham[i].getTenSanPham() == TenSanPham)
            {
                return i;
            }
        }

        cout << "Khong Tim Thay Ten San Pham \n";
        return -1;
    }

    void XoaSanPham()
    {
        int index = TimKiemIndexSanPhamTheoTen();

        if (index == -1)
            return;

        DanhSachSanPham.erase(DanhSachSanPham.begin() + index);
        CapNhatCSDL();
        cout << "Xoa San Pham Thanh Cong \n";
    }

};

class QuanLyCuaHang
{
public:
    vector<string> getTenFileCuaHang()
    {
        fstream fin;

        fin.open(DANHSACHCUAHANG);

        int SoLuong;
        fin >> SoLuong;

        string rac;
        getline(fin, rac);

        vector<string> TenFileCuaHang;
        TenFileCuaHang.resize(SoLuong);

        for (int i = 0; i < SoLuong; i++)
        {
            getline(fin, TenFileCuaHang[i]);
        }

        fin.close();

        return TenFileCuaHang;
    }

    vector<CuaHang> getDanhSachCuaHang()
    {
        vector<string> TenFileCuaHang = getTenFileCuaHang();

        int SoLuongCuaHang = TenFileCuaHang.size();

        vector<CuaHang> DanhSachCuaHang;
        DanhSachCuaHang.resize(SoLuongCuaHang);

        for (int i = 0; i < SoLuongCuaHang; i++)
        {
            DanhSachCuaHang[i].TruyXuatCSDL(TenFileCuaHang[i]);
        }

        return DanhSachCuaHang;
    }

    int TimKiemIndexCuaHangTheoTen(vector<CuaHang> DanhSach)
    {
        cout << "\nDanh Sach Cua Hang: \n";
        for (int i = 0; i < DanhSach.size(); i++)
        {
            cout << i + 1 << ". " << DanhSach[i].getTenCuaHang() << '\n';
        }

        string TenCuaHang;

        cout << "Nhap Ten Cua Hang:  ";
        getline(cin, TenCuaHang);

        for (int i = 0; i < DanhSach.size(); i++)
        {
            if (DanhSach[i].getTenCuaHang() == TenCuaHang)
            {
                return i;
            }
        }

        cout << "Khong Tim Thay Ten Cua Hang \n";
        return -1;
    }

    void ThemSanPhamChoMotCuaHangBatKi(vector<CuaHang> DanhSach)
    {
        int index = TimKiemIndexCuaHangTheoTen(DanhSach);

        if (index == -1)
            return;

        DanhSach[index].ThemSanPham();
    }

    void XoaSanPhamChoMotCuaHangBatKi(vector<CuaHang> DanhSach)
    {
        int index = TimKiemIndexCuaHangTheoTen(DanhSach);

        if (index == -1)
            return;

        DanhSach[index].XoaSanPham();
    }

    void Menu()
    {
        while (1)
        {
            cout << "\n1. Them San Pham Cho 1 Cua Hang Bat Ki \n";
            cout << "2. Xoa San Pham Cho 1 Cua Hang Bat Ki \n";
            cout << "3. Thoat \n";

            cout << "Lua Chon (1 / 2 / 3):  ";

            char choice;
            cin >> choice;
            cin.ignore();

            if (choice == '1')
            {
                ThemSanPhamChoMotCuaHangBatKi(getDanhSachCuaHang());
            }
            else if (choice == '2')
            {
                XoaSanPhamChoMotCuaHangBatKi(getDanhSachCuaHang());
            }
            else
            {
                break;
            }
        }
    }
};

