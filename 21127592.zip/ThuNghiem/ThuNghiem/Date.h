#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

class Date
{
private:
	int ngay;
	int thang;
	int nam;
public:
	Date() {}
	Date(int ngay, int thang, int nam)
	{
		this->ngay = ngay;
		this->thang = thang;
		this->nam = nam;
	}

	int getNgay() { return ngay; }
	int getThang() { return thang; }
	int getNam() { return nam; }

	void setNgay(int ngay) { this->ngay = ngay; }
	void setThang(int thang) { this->thang = thang; }
	void setNam(int nam) { this->nam = nam; }

	bool LaNamNhuan();

	bool KiemTraHopLe();

	void Nhap();

	void Xuat();
};


bool Date::LaNamNhuan()
{
	if (this->nam % 100 == 0)
	{
		return (this->nam % 400 == 0);
	}
	else
	{
		return (this->nam % 4 == 0);
	}
}

bool Date::KiemTraHopLe()
{
	if ((ngay < 1 || ngay > 31) || (thang < 1 || thang > 12) || nam < 0)
	{
		return false;
	}

	if (thang == 2)
	{
		if (LaNamNhuan())
		{
			return (ngay <= 29);
		}
		else
		{
			return (ngay <= 28);
		}
	}
	else if (thang == 4 || thang == 6 || thang == 9 || thang == 11)
	{
		return (ngay <= 30);
	}

	return true;
}

void Date::Nhap()
{
	do
	{
		std::cout << "Ngay = ";
		std::cin >> ngay;
		std::cin.ignore();

		std::cout << "Thang = ";
		std::cin >> thang;
		std::cin.ignore();

		std::cout << "Nam = ";
		std::cin >> nam;
		std::cin.ignore();
	} while (KiemTraHopLe() == false);
}

void Date::Xuat()
{
	std::cout << ngay << '/' << thang << '/' << nam << '\n';
}