#pragma once

#include "SanPham.h"

using namespace std;

class MaGiamGia
{
    string TenMa;
    int PhanTram;
    int SoTienToiDa;
public:
    MaGiamGia() {}
    MaGiamGia(string Ten, int phantram, int soTien)
    {
        TenMa = Ten;
        PhanTram = phantram;
        SoTienToiDa = soTien;
    }

    string getTenMa() { return TenMa; }
    int getPhanTram() { return PhanTram; }
    int getSoTienToiDa() { return SoTienToiDa; }

    bool KiemTraTenMaHopLe()
    {
        return (TenMa.size() <= 10);
    }
    void Nhap()
    {
        do {
            cout << "Nhap Ten Ma Giam Gia:  ";
            getline(cin, TenMa);
        } while (TenMa.size() <= 0 || TenMa.size() > 10);
    }
};

class MaGiamGiaToanSan :public MaGiamGia
{
public:
    MaGiamGiaToanSan() {}
    MaGiamGiaToanSan(string Ten, int phantram, int soTien) : MaGiamGia(Ten, phantram, soTien) {}
};

MaGiamGiaToanSan MaToanSan1("TOANSAN1", 3, 15);
MaGiamGiaToanSan MaToanSan2("TOANSAN2", 6, 30);

vector<MaGiamGiaToanSan> DSMaGiamGiaToanSan = { MaToanSan1, MaToanSan2 };

class MaGiamGiaTheoDanhMuc :public MaGiamGia
{
    string DanhMuc;
public:
    MaGiamGiaTheoDanhMuc() {}
    MaGiamGiaTheoDanhMuc(string Ten, int phantram, int soTien, string danhmuc) : MaGiamGia(Ten, phantram, soTien) {
        DanhMuc = danhmuc;
    }

    string getDanhMuc() { return DanhMuc; }
};

MaGiamGiaTheoDanhMuc MaDanhMucTHOITRANG("DANHMUC1", 5, 20, THOITRANG);
MaGiamGiaTheoDanhMuc MaDanhMucTHOITRANGNAM("DANHMUC2", 5, 20, THOITRANGNAM);
MaGiamGiaTheoDanhMuc MaDanhMucTHOITRANGNU("DANHMUC3", 5, 20, THOITRANGNU);
MaGiamGiaTheoDanhMuc MaDanhMucKHAC("DANHMUC4", 5, 20, KHAC);

vector<MaGiamGiaTheoDanhMuc> DSMaGiamGiaTheoDanhMuc = { MaDanhMucTHOITRANG, MaDanhMucTHOITRANGNAM, MaDanhMucTHOITRANGNU, MaDanhMucKHAC };


class MaGiamGiaSinhNhat :public MaGiamGia
{
public:
    MaGiamGiaSinhNhat() {}
    MaGiamGiaSinhNhat(string Ten, int phantram, int soTien) :MaGiamGia(Ten, phantram, soTien) {}

    bool KiemTraHopLe(Date NgaySinh, Date NgayDatDon)
    {
        return (NgaySinh.getNgay() == NgayDatDon.getNgay()
            && NgaySinh.getThang() == NgayDatDon.getThang()
            && NgaySinh.getNam() == NgayDatDon.getNam());
    }
};

MaGiamGiaSinhNhat MaSinhNhat("BIRTHDAY", 10, 35);