#pragma once
#include "CuaHang.h"

const int MUOITRIEU = 10000;
const int NAMMUOITRIEU = 50000;
const int HAITRAMTRIEU = 200000;
const string HANGTHUONG = "HANG THUONG";
const string HANGDONG = "HANG DONG";
const string HANGBAC = "HANG BAC";
const string HANGVANG = "HANG VANG";


class GioHang
{
    vector<SanPham> DanhSachSanPham;
    int TongSoLuongSanPham;
    int TongTienHang;
    int TongThanhToan;
public:
    GioHang() {}
    GioHang(vector<SanPham> danhsach, int tongSL, int tongtien, int tongthanhtoan)
    {
        DanhSachSanPham = danhsach;
        TongSoLuongSanPham = tongSL;
        TongTienHang = tongtien;
        TongThanhToan = tongthanhtoan;
    }

    void setDanhSachSanPham(vector<SanPham> Danhsach) { DanhSachSanPham = Danhsach; }
    void setTongSoLuongSanPham() {
        TongSoLuongSanPham = 0;
        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            TongSoLuongSanPham += DanhSachSanPham[i].getSoLuongCoSan();
        }
    }
    void setTongTienHang() {
        TongTienHang = 0;
        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            TongTienHang += DanhSachSanPham[i].getGiaBan() * DanhSachSanPham[i].getSoLuongCoSan();
        }
    }
    void setTongThanhToan(int thanhtoan) { TongThanhToan = thanhtoan; }

    vector<SanPham> getDanhSachSanPham() { return DanhSachSanPham; }
    int getTongSoLuongSanPham()
    {
        int SL = 0;
        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            SL += DanhSachSanPham[i].getSoLuongCoSan();
        }
        return SL;
    }
    int getTongTienHang()
    {
        int tien = 0;
        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            tien += DanhSachSanPham[i].getGiaBan() * DanhSachSanPham[i].getSoLuongCoSan();
        }
        return tien;
    }
    int getTongThanhToan() { return TongThanhToan; }


    void clearGioHang() {
        DanhSachSanPham.clear();
        TongSoLuongSanPham = 0;
        TongTienHang = 0;
        TongThanhToan = 0;
    }

    void ThemSanPhamVaoGioHang(SanPham sp)
    {
        DanhSachSanPham.push_back(sp);
        TongSoLuongSanPham += sp.getSoLuongCoSan();
        TongTienHang += sp.getSoLuongCoSan() * sp.getGiaBan();

        cout << "Them San Pham Vao Gio Hang Thanh Cong \n";
    }

    int TimKiemSanPhamTrongGioHang()
    {
        cout << "\nDanh Sach San Pham Trong Gio Hang: \n";

        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            cout << i + 1 << ". " << DanhSachSanPham[i].getTenSanPham() << '\n';
        }

        string TenSanPham;
        cout << "Nhap Ten San Pham:  ";
        getline(cin, TenSanPham);

        for (int i = 0; i < DanhSachSanPham.size(); i++)
        {
            if (DanhSachSanPham[i].getTenSanPham() == TenSanPham)
            {
                return i;
            }
        }

        cout << "Khong Tim Thay Ten San Pham \n";
        return -1;
    }

    void XoaSanPhamKhoiGioHang()
    {
        int index = TimKiemSanPhamTrongGioHang();

        if (index == -1)
        {
            cout << "Khong Tim Thay San Pham \n";
            return;
        }
        DanhSachSanPham.erase(DanhSachSanPham.begin() + index);

        setTongSoLuongSanPham();
        setTongTienHang();

        cout << "Xoa San Pham Khoi Gio Hang Thanh Cong \n";

    }

};

class DonHang
{
    string MaDonHang;
    GioHang gioHang;
    Date NgayDatDon;
public:
    DonHang() {}
    DonHang(string ma, GioHang gio, Date ngaydat)
    {
        MaDonHang = ma;
        gioHang = gio;
        NgayDatDon = ngaydat;
    }

    string getMaDonHang() { return MaDonHang; }
    GioHang getGioHang() { return gioHang; }
    Date getNgayDatDon() { return NgayDatDon; }
    int getTongThanhToan() { return gioHang.getTongThanhToan(); }

    void setMaDonHang(string ma) { MaDonHang = ma; }
    void setGioHang(GioHang gio) { gioHang = gio; }
    void setNgayDatDon(Date ngay) { NgayDatDon = ngay; }
};



class KhachHang
{
    string DiaChiEmail;
    string TenKhachHang;
    string DiaChiNhanHang;
    bool GioiTinhNam;
    Date NgaySinh;
    GioHang GioHangHienTai;
    vector<DonHang> DanhSachDonHang;

    int TongChiTieu;
public:
    KhachHang() {}
    KhachHang(string mail, string ten, string diachi, bool gioitinh, Date sinhnhat, GioHang gio, vector<DonHang> danhsach)
    {
        DiaChiEmail = mail;
        TenKhachHang = ten;
        DiaChiNhanHang = diachi;
        GioiTinhNam = gioitinh;
        NgaySinh = sinhnhat;
        GioHangHienTai = gio;
        DanhSachDonHang = danhsach;
    }

    string getDiaChiEmail() { return DiaChiEmail; }
    string getTenKhachHang() { return TenKhachHang; }
    string getDiaChiNhanHang() { return DiaChiNhanHang; }
    Date getNgaySinh() { return NgaySinh; }
    GioHang getGioHang() { return GioHangHienTai; }
    vector<DonHang> getDanhSachDonHang() { return DanhSachDonHang; }
    int getTongChiTieu() { 
        int tongChiTieu = 0;
        for (int i = 0; i < DanhSachDonHang.size(); i++)
        {
            tongChiTieu += DanhSachDonHang[i].getTongThanhToan();
        }
        return tongChiTieu;
    }

    void setDiaChiEmail(string mail) { DiaChiEmail = mail; }
    void setTenKhachHang(string ten) { TenKhachHang = ten; }
    void setDiaChiNhanHang(string diachi) { DiaChiNhanHang = diachi; }
    void setGioiTinhNam(bool gioitinh) { GioiTinhNam = gioitinh; }
    void setNgaySinh(Date sinhnhat) { NgaySinh = sinhnhat; }
    void setGioHangHienTai(GioHang gio) { GioHangHienTai = gio; }
    void setDanhSachDonHang(vector<DonHang> dsDon) { DanhSachDonHang = dsDon; }
    void setTongChiTieu(int chitieu) { TongChiTieu = chitieu; }

    void CapNhatCSDL()
    {
        fstream fout;

        fout.open(DiaChiEmail + ".txt", ios::out);

        fout << DiaChiEmail << '\n';
        fout << TenKhachHang << '\n';
        fout << DiaChiNhanHang << '\n';
        if (GioiTinhNam)
            fout << NAM << '\n';
        else
            fout << NU << '\n';
        fout << NgaySinh.getNgay() << '\n';
        fout << NgaySinh.getThang() << '\n';
        fout << NgaySinh.getNam() << '\n';

        fout << getTongChiTieu() << '\n'; // TONG CHI TIEU

        vector<SanPham> DanhSachSanPham = GioHangHienTai.getDanhSachSanPham();

        int SoLoaiSanPham = DanhSachSanPham.size();

        fout << SoLoaiSanPham << '\n';

        for (int i = 0; i < SoLoaiSanPham; i++)
        {
            fout << DanhSachSanPham[i].getTenSanPham() << '\n';
            fout << DanhSachSanPham[i].getLoaiSanPham() << '\n';
            fout << DanhSachSanPham[i].getGiaBan() << '\n';
            fout << DanhSachSanPham[i].getSoLuongCoSan() << '\n';
        }

        fout << GioHangHienTai.getTongSoLuongSanPham() << '\n';
        fout << GioHangHienTai.getTongTienHang() << '\n';
        fout << GioHangHienTai.getTongThanhToan() << '\n';

        int SoLuongDonHang = DanhSachDonHang.size();

        fout << SoLuongDonHang << '\n';


        for (int i = 0; i < SoLuongDonHang; i++)
        {
            fout << DanhSachDonHang[i].getMaDonHang() << '\n';

            GioHang gioHang = DanhSachDonHang[i].getGioHang();

            DanhSachSanPham.clear();
            DanhSachSanPham = gioHang.getDanhSachSanPham();

            SoLoaiSanPham = DanhSachSanPham.size();

            fout << SoLoaiSanPham << '\n';

            for (int j = 0; j < SoLoaiSanPham; j++)
            {
                fout << DanhSachSanPham[j].getTenSanPham() << '\n';
                fout << DanhSachSanPham[j].getLoaiSanPham() << '\n';
                fout << DanhSachSanPham[j].getGiaBan() << '\n';
                fout << DanhSachSanPham[j].getSoLuongCoSan() << '\n';
            }

            fout << gioHang.getTongSoLuongSanPham() << '\n';
            fout << gioHang.getTongTienHang() << '\n';
            fout << gioHang.getTongThanhToan() << '\n';

            Date ngayDatDon = DanhSachDonHang[i].getNgayDatDon();
            fout << ngayDatDon.getNgay() << '\n';
            fout << ngayDatDon.getThang() << '\n';
            fout << ngayDatDon.getNam() << '\n';
        }

        fout.close();
    }

    void TruyXuatCSDL(string path)
    {
        fstream fin;

        fin.open(path);

        getline(fin, DiaChiEmail);
        getline(fin, TenKhachHang);
        getline(fin, DiaChiNhanHang);

        string Gioi;
        getline(fin, Gioi);

        if (Gioi == NAM)
            GioiTinhNam = true;
        else
            GioiTinhNam = false;

        int ngay, thang, nam; // ngay sinh
        string rac;
        fin >> ngay;
        getline(fin, rac);

        fin >> thang;
        getline(fin, rac);

        fin >> nam;
        getline(fin, rac);

        NgaySinh.setNgay(ngay);
        NgaySinh.setThang(thang);
        NgaySinh.setNam(nam);

        fin >> TongChiTieu; // TONG CHI TIEU
        getline(fin, rac);

        int SLSanPhamTrongGioHang; // gio hang hien tai
        fin >> SLSanPhamTrongGioHang;
        getline(fin, rac);

        vector<SanPham> SPtrongGioHang;
        SPtrongGioHang.resize(SLSanPhamTrongGioHang);

        string TenSP;
        string LoaiSP;
        int Gia;
        int SLCoSAN;

        for (int i = 0; i < SLSanPhamTrongGioHang; i++)
        {
            getline(fin, TenSP);
            getline(fin, LoaiSP);
            fin >> Gia;
            getline(fin, rac);
            fin >> SLCoSAN;
            getline(fin, rac);

            SPtrongGioHang[i].setTenSanPham(TenSP);
            SPtrongGioHang[i].setLoaiSanPham(LoaiSP);
            SPtrongGioHang[i].setGiaBan(Gia);
            SPtrongGioHang[i].setSoLuongCoSan(SLCoSAN);
        }

        int tongSL, TienHang, ThanhToan;
        fin >> tongSL;
        getline(fin, rac);
        fin >> TienHang;
        getline(fin, rac);
        fin >> ThanhToan;
        getline(fin, rac);

        GioHangHienTai.setDanhSachSanPham(SPtrongGioHang);
        GioHangHienTai.setTongSoLuongSanPham();
        GioHangHienTai.setTongTienHang();
        GioHangHienTai.setTongThanhToan(ThanhToan);

        int SLDonHang;
        fin >> SLDonHang;
        getline(fin, rac);

        DanhSachDonHang.resize(SLDonHang);

        GioHang tempGioHang;
        Date tempNgayDatDon;
        string tempMaDonhang;
        int SLSanPhamTrongDonhang;

        for (int i = 0; i < SLDonHang; i++)
        {
            getline(fin, tempMaDonhang);
            fin >> SLSanPhamTrongDonhang;
            getline(fin, rac);

            SPtrongGioHang.clear();
            SPtrongGioHang.resize(SLSanPhamTrongDonhang);

            for (int j = 0; j < SLSanPhamTrongDonhang; j++)
            {
                getline(fin, TenSP);
                getline(fin, LoaiSP);
                fin >> Gia;
                getline(fin, rac);
                fin >> SLCoSAN;
                getline(fin, rac);

                SPtrongGioHang[j].setTenSanPham(TenSP);
                SPtrongGioHang[j].setLoaiSanPham(LoaiSP);
                SPtrongGioHang[j].setGiaBan(Gia);
                SPtrongGioHang[j].setSoLuongCoSan(SLCoSAN);
            }

            fin >> tongSL;
            getline(fin, rac);
            fin >> TienHang;
            getline(fin, rac);
            fin >> ThanhToan;
            getline(fin, rac);

            tempGioHang.setDanhSachSanPham(SPtrongGioHang);
            tempGioHang.setTongSoLuongSanPham();
            tempGioHang.setTongTienHang();
            tempGioHang.setTongThanhToan(ThanhToan);

            fin >> ngay; // ngay dat don
            getline(fin, rac);

            fin >> thang;
            getline(fin, rac);

            fin >> nam;
            getline(fin, rac);

            tempNgayDatDon.setNgay(ngay);
            tempNgayDatDon.setThang(thang);
            tempNgayDatDon.setNam(nam);

            DanhSachDonHang[i].setMaDonHang(tempMaDonhang);
            DanhSachDonHang[i].setGioHang(tempGioHang);
            DanhSachDonHang[i].setNgayDatDon(tempNgayDatDon);
        }



        fin.close();
    }

    void ThemSanPhamVaoGioHang(SanPham sp)
    {
        GioHangHienTai.ThemSanPhamVaoGioHang(sp);
    }

    void XoaSanPhamTrongGioHang()
    {
        GioHangHienTai.XoaSanPhamKhoiGioHang();
        CapNhatCSDL();
    }

    string PhanLoaiKhachHang()
    {
        if (TongChiTieu < MUOITRIEU)
        {
            return HANGTHUONG;
        }
        else if (TongChiTieu < NAMMUOITRIEU)
        {
            return HANGDONG;
        }
        else if (TongChiTieu < HAITRAMTRIEU)
        {
            return HANGBAC;
        }
        else
        {
            return HANGVANG;
        }
    }

    void ThanhToanChoGioHang()
    {
        cout << "\nNhap Ngay Dat Don: \n";
        Date ngayDatDon;
        ngayDatDon.Nhap();

        cout << "\nTHANH TOAN: \n";
        cout << "Su Dung Ma Giam Gia: \n";

        cout << "1. CO \n";
        cout << "2. KHONG \n";
        cout << "Lua Chon (1 / 2):  ";

        char choice;
        cin >> choice;
        cin.ignore();

        if (choice == '1')
        {
            cout << "\nChon Loai Ma Giam Gia: \n";
            cout << "1. Ma Giam Gia Toan San \n";
            cout << "2. Ma Giam Gia Sinh Nhat \n";

            cout << "Lua Chon (1 / 2):  ";

            cin >> choice;
            cin.ignore();

            if (choice == '1')
            {

                MaGiamGiaToanSan tempMaGiamGia;
                tempMaGiamGia.Nhap();

                bool flag = false;

                for (int i = 0; i < DSMaGiamGiaToanSan.size(); i++)
                {
                    if (DSMaGiamGiaToanSan[i].getTenMa() == tempMaGiamGia.getTenMa())
                    {
                        int SoTienDuocGiamTheoPhanTram = GioHangHienTai.getTongTienHang() * DSMaGiamGiaToanSan[i].getPhanTram() / 100;

                        if (SoTienDuocGiamTheoPhanTram < DSMaGiamGiaToanSan[i].getSoTienToiDa())
                        {
                            GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang() - SoTienDuocGiamTheoPhanTram);
                        }
                        else
                        {
                            GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang() - DSMaGiamGiaToanSan[i].getSoTienToiDa());
                        }

                        cout << "Ap Dung Ma Giam Gia Toan San Thanh Cong \n";
                        flag = true;
                        break;
                    }
                }

                if (flag == false)
                {
                    cout << "Ten Ma Khong Hop Le \n";
                    GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang());
                }
            }
            else
            {
                MaGiamGiaSinhNhat tempMaGiamGia;
                tempMaGiamGia.Nhap();

                if (tempMaGiamGia.getTenMa() == MaSinhNhat.getTenMa() && tempMaGiamGia.KiemTraHopLe(NgaySinh, ngayDatDon))
                {
                    int SoTienDuocGiam = GioHangHienTai.getTongTienHang() * MaSinhNhat.getPhanTram() / 100;

                    if (SoTienDuocGiam < MaSinhNhat.getSoTienToiDa())
                    {
                        GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang() - SoTienDuocGiam);
                    }
                    else
                    {
                        GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang() - MaSinhNhat.getSoTienToiDa());
                    }

                    cout << "Ap Dung Ma Giam Gia Sinh Nhat Thanh Cong \n";
                }
                else
                {
                    cout << "Ten Ma Khong Hop Le \n";
                    GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang());
                }
            }
        }
        else
        {
            GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongTienHang());
        }

        string type = PhanLoaiKhachHang();
        if (type == HANGDONG)
        {
            cout << "Giam 1% cho Khach Hang " << HANGDONG << '\n';
            GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongThanhToan() * 0.99);
        }
        else if (type == HANGBAC)
        {
            cout << "Giam 2% cho Khach Hang " << HANGBAC << '\n';
            GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongThanhToan() * 0.98);
        }
        else if (type == HANGVANG)
        {
            cout << "Giam 4% cho Khach Hang " << HANGVANG << '\n';
            GioHangHienTai.setTongThanhToan(GioHangHienTai.getTongThanhToan() * 0.96);
        }
        

        cout << "\nTong So Tien Thanh Toan:  " << GioHangHienTai.getTongThanhToan() << '\n';

        DonHang tempDonHang("Ma Don Hang", GioHangHienTai, ngayDatDon);
        DanhSachDonHang.push_back(tempDonHang);

        GioHangHienTai.clearGioHang();

        CapNhatCSDL();
    }

    void XemGioHangHienTai()
    {
        vector<SanPham> tempDSSanPham = GioHangHienTai.getDanhSachSanPham();

        for (int i = 0; i < tempDSSanPham.size(); i++)
        {
            cout << i + 1 << ". \n";
            cout << "Ten SP:  " << tempDSSanPham[i].getTenSanPham() << '\n';
            cout << "Gia:  " << tempDSSanPham[i].getGiaBan() << '\n';
            cout << "So Luong:  " << tempDSSanPham[i].getSoLuongCoSan() << '\n';
        }

        cout << "Tong SL:  " << GioHangHienTai.getTongSoLuongSanPham() << '\n';
        cout << "Tong Tien Hang:  " << GioHangHienTai.getTongTienHang() << "\n";
        cout << "Thanh Toan:  " << GioHangHienTai.getTongThanhToan() << "\n";
    }
};

class QuanLyKhachHang
{
public:
    vector<string> getTenFileKhachHang()
    {
        fstream fin;

        fin.open(DANHSACHKHACHHANG);

        int SoLuong;
        fin >> SoLuong;

        string rac;
        getline(fin, rac);

        vector<string> TenFileKhachHang;
        TenFileKhachHang.resize(SoLuong);

        for (int i = 0; i < SoLuong; i++)
        {
            getline(fin, TenFileKhachHang[i]);
        }

        fin.close();

        return TenFileKhachHang;
    }

    vector<KhachHang> getDanhSachKhachHang()
    {
        vector<string> TenFileKhachHang = getTenFileKhachHang();

        int SoLuongKhachHang = TenFileKhachHang.size();

        vector<KhachHang> DanhSachKhachHang;
        DanhSachKhachHang.resize(SoLuongKhachHang);

        for (int i = 0; i < SoLuongKhachHang; i++)
        {
            DanhSachKhachHang[i].TruyXuatCSDL(TenFileKhachHang[i]);
        }

        return DanhSachKhachHang;
    }

    int TimKiemIndexKhachHangTheoMail(vector<KhachHang> DanhSach)
    {
        cout << "\nDanh Sach Email Khach Hang: \n";
        for (int i = 0; i < DanhSach.size(); i++)
        {
            cout << i + 1 << ". " << DanhSach[i].getDiaChiEmail() << '\n';
        }

        string MailKhachHang;

        cout << "Nhap Email Khach Hang:  ";
        getline(cin, MailKhachHang);

        for (int i = 0; i < DanhSach.size(); i++)
        {
            if (DanhSach[i].getDiaChiEmail() == MailKhachHang)
            {
                return i;
            }
        }

        cout << "Khong Tim Thay Email Khach Hang \n";
        return -1;
    }

};

