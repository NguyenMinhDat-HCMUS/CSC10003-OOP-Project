#include "KhachHang.h"


//using namespace std;

class Admin
{
    KhachHang Client;
    
public:
    bool DangNhap()
    {
        QuanLyKhachHang clientManager;
        vector<KhachHang> DSKhachHang = clientManager.getDanhSachKhachHang();

        int indexKH = clientManager.TimKiemIndexKhachHangTheoMail(DSKhachHang);
        if (indexKH == -1)
        {
            return false;
        }
        else
        {
            Client = DSKhachHang[indexKH];
        }
    }

    Admin()
    {
        bool rslt = false;
        while (rslt == false)
        {
            rslt = DangNhap();
        }
    }

    void ThemSanPhamVaoGioHang()
    {
        QuanLyCuaHang storeManager;
        // QuanLyKhachHang clientManager;

        // vector<KhachHang> DSKhachHang = clientManager.getDanhSachKhachHang();
        vector<CuaHang> DSCuaHang = storeManager.getDanhSachCuaHang();

        /*int indexKH = clientManager.TimKiemIndexKhachHangTheoMail(DSKhachHang);
        if (indexKH == -1)
        {
            return;
        }*/

        int indexCH = storeManager.TimKiemIndexCuaHangTheoTen(DSCuaHang);
        if (indexCH == -1)
        {
            return;
        }

        int indexSP = DSCuaHang[indexCH].TimKiemIndexSanPhamTheoTen();
        if (indexSP == -1)
        {
            return;
        }

        vector<SanPham> dsSanPham = DSCuaHang[indexCH].getDanhSachSanPham();
        SanPham tempSP = dsSanPham[indexSP];

        int SLThemVao;

        do
        {
            cout << "So Luong:  ";
            cin >> SLThemVao;
            cin.ignore();
        } while (SLThemVao <= 0 || SLThemVao > tempSP.getSoLuongCoSan());

        int SLtrongGioHang = SLThemVao;

        tempSP.setSoLuongCoSan(SLtrongGioHang);

        // DSKhachHang[indexKH].ThemSanPhamVaoGioHang(tempSP);
        // DSKhachHang[indexKH].CapNhatCSDL();

        Client.ThemSanPhamVaoGioHang(tempSP);
        Client.CapNhatCSDL();
    }

    void XoaSanPhamKhoiGioHang()
    {
        /*QuanLyKhachHang clientManager;

        vector<KhachHang> DSKhachHang = clientManager.getDanhSachKhachHang();

        int indexKH = clientManager.TimKiemIndexKhachHangTheoMail(DSKhachHang);
        if (indexKH == -1)
        {
            return;
        }*/
        
        // DSKhachHang[indexKH].XoaSanPhamTrongGioHang();
        Client.XoaSanPhamTrongGioHang();
    }


    void ThanhToanGioHang()
    {
        QuanLyCuaHang storeManager;
        // QuanLyKhachHang clientManager;

        // vector<KhachHang> DSKhachHang = clientManager.getDanhSachKhachHang();
        vector<CuaHang> DSCuaHang = storeManager.getDanhSachCuaHang();

        /*int indexKH = clientManager.TimKiemIndexKhachHangTheoMail(DSKhachHang);
        if (indexKH == -1)
        {
            return;
        }*/


        // GioHang tempGioHang = DSKhachHang[indexKH].getGioHang();
        GioHang tempGioHang = Client.getGioHang();

        vector<SanPham> DSSanPhamTrongGioHang = tempGioHang.getDanhSachSanPham();

        for (int i = 0; i < DSSanPhamTrongGioHang.size(); i++)
        {
            for (int j = 0; j < DSCuaHang.size(); j++)
            {
                vector<SanPham> DSSanPhamTrongCuaHang = DSCuaHang[j].getDanhSachSanPham();
                for (int k = 0; k < DSSanPhamTrongCuaHang.size(); k++)
                {
                    if (DSSanPhamTrongGioHang[i].getTenSanPham() == DSSanPhamTrongCuaHang[k].getTenSanPham())
                    {
                        int SoLuongConLai = DSSanPhamTrongCuaHang[k].getSoLuongCoSan() - DSSanPhamTrongGioHang[i].getSoLuongCoSan();
                        DSSanPhamTrongCuaHang[k].setSoLuongCoSan(SoLuongConLai);
                    }
                }
                DSCuaHang[j].setDanhSachSanPham(DSSanPhamTrongCuaHang);
            }
        }


        for (int i = 0; i < DSCuaHang.size(); i++)
        {
            DSCuaHang[i].CapNhatCSDL();
        }

        Client.ThanhToanChoGioHang();
    }

    void Menu()
    {
        while (1)
        {
            cout << "\n0. Xem Gio Hang Hien Tai \n";
            cout << "1. Them SP vao Gio Hang \n";
            cout << "2. Xoa SP khoi Gio Hang \n";
            cout << "3. Thanh Toan Gio Hang \n";
            cout << "4. Thoat \n";

            char choice;
            cout << "Lua Chon (1/2/3) :  ";
            cin >> choice;
            cin.ignore();

            if (choice == '0')
            {
                Client.XemGioHangHienTai();
            }
            else if (choice == '1')
            {
                ThemSanPhamVaoGioHang();
            }
            else if (choice == '2')
            {
                XoaSanPhamKhoiGioHang();
            }
            else if (choice == '3')
            {
                ThanhToanGioHang();
            }
            else
            {
                break;
            }
        }
    }
};


int main()
{
    while (1)
    {
        cout << "\nChon MODE: \n";
        cout << "1. QUAN TRI VIEN (THEM / BOT San Pham trong Cua Hang) \n";
        cout << "2. NGUOI DUNG (MUA SAM San Pham) \n";
        cout << "3. THOAT \n";

        char choice;
        cout << "Lua Chon (1 / 2 / 3) :  ";
        cin >> choice;
        cin.ignore();

        if (choice == '1')
        {
            QuanLyCuaHang storeManager;
            storeManager.Menu();
        }
        else if (choice == '2')
        {
            Admin client;
            client.Menu();
        }
        else
        {
            break;
        }
    }
    

    /*Admin admin;
    admin.Menu();*/



    /*SanPham a1("Ao thun nam", AONAM, 100, 1357);
    SanPham a2("Ao so mi nam", AONAM, 130, 3107);

    SanPham b1("Quan thun nam", QUANNAM, 170, 3113);
    SanPham b2("Quan kaki nam", QUANNAM, 190, 1679);

    vector<SanPham> danhsachAo;
    danhsachAo.push_back(a1);
    danhsachAo.push_back(a2);

    vector<SanPham> danhsachQuan;
    danhsachQuan.push_back(b1);
    danhsachQuan.push_back(b2);

    CuaHang c1("Men Clothing Store", danhsachAo);
    c1.CapNhatCSDL();*/


    /*CuaHang c2;
    c2.Nhap();
    c2.CapNhatCSDL();*/

    /*Date ngay1(13, 3, 2003);
    Date ngay2(14, 4, 2004);

    GioHang gio1(danhsachAo, 3, 412, 379);
    GioHang gio2(danhsachQuan, 2, 641, 587);

    DonHang don1("ZZ", gio1, ngay1);
    DonHang don2("EZ", gio2, ngay2);

    vector<DonHang> danhsachDon;
    danhsachDon.push_back(don1);
    danhsachDon.push_back(don2);

    KhachHang d("mdat@gmail", "Dat que", "853 Le Duc Tho", true, ngay1, gio2, danhsachDon);
    d.CapNhatCSDL();*/

}

